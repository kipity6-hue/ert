# Cars Messenger (starter)

A small browser messenger with phone-number registration, SMS OTP, user list, and direct messages. It is a starter project, not a production-ready service.

## Run locally
1. Install Node.js 18+.
2. Unzip this project and open a terminal in its folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env` and set a long `SESSION_SECRET`.
5. Run `npm start`.
6. Visit http://localhost:3000

## SMS verification
- For real SMS, fill in `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, and `TWILIO_PHONE_NUMBER` in `.env`.
- Without Twilio credentials, the server prints the 6-digit code in the terminal. This is for local testing only.

## Notes before deployment
- Use HTTPS and secure cookies; set `cookie.secure=true` behind HTTPS.
- Use a persistent session store, database, rate limiting, abuse prevention, and stronger OTP controls.
- This sample stores users/messages in a local JSON file and is intended for demonstration.
- Twilio setup and SMS costs/verification rules apply.
