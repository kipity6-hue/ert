const $=id=>document.getElementById(id);let me=null,active=null,poll=null;
async function api(path,opts={}){const r=await fetch(path,{headers:{'Content-Type':'application/json'},...opts});let data={};try{data=await r.json()}catch{}if(!r.ok)throw Error(data.error||'Request failed');return data}
function showAuth(){ $('auth').hidden=false;$('app').hidden=true; }
function showApp(){ $('auth').hidden=true;$('app').hidden=false;$('me').textContent=me.phone;loadUsers();}
$('send').onclick=async()=>{try{const d=await api('/api/send-code',{method:'POST',body:JSON.stringify({phone:$('phone').value})});$('code-area').hidden=false;$('auth-msg').textContent=d.message;}catch(e){$('auth-msg').textContent=e.message}};
$('verify').onclick=async()=>{try{const d=await api('/api/verify',{method:'POST',body:JSON.stringify({phone:$('phone').value,code:$('code').value})});me=d.user;showApp();}catch(e){$('auth-msg').textContent=e.message}};
$('logout').onclick=async()=>{await api('/api/logout',{method:'POST'});me=null;active=null;if(poll)clearInterval(poll);showAuth()};
async function loadUsers(){const users=await api('/api/users');$('users').innerHTML='';users.forEach(u=>{const el=document.createElement('div');el.className='user'+(active===u.id?' active':'');el.textContent=u.phone;el.onclick=()=>openChat(u);$('users').append(el)});}
async function openChat(u){active=u.id;$('chat-head').textContent=u.phone;await loadMessages();loadUsers();if(poll)clearInterval(poll);poll=setInterval(loadMessages,2500);}
async function loadMessages(){if(!active)return;const list=await api('/api/messages/'+active);const box=$('messages');box.innerHTML='';list.forEach(m=>{const b=document.createElement('div');b.className='bubble'+(m.from===me.id?' mine':'');b.textContent=m.text;const s=document.createElement('small');s.textContent=new Date(m.at).toLocaleString();b.append(s);box.append(b)});box.scrollTop=box.scrollHeight;}
$('send-form').onsubmit=async e=>{e.preventDefault();const text=$('message').value.trim();if(!text||!active)return;try{await api('/api/messages',{method:'POST',body:JSON.stringify({to:active,text})});$('message').value='';await loadMessages();}catch(err){alert(err.message)}};
(async()=>{const d=await api('/api/me');if(d.user){me=d.user;showApp()}else showAuth()})();
