require('dotenv').config();
const express = require('express');
const session = require('express-session');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DB = path.join(__dirname, 'data.json');
let db = { users: [], messages: [] };
try { if (fs.existsSync(DB)) db = JSON.parse(fs.readFileSync(DB, 'utf8')); } catch {}
function save(){ fs.writeFileSync(DB, JSON.stringify(db, null, 2)); }
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'dev-secret-change-me',
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: false, maxAge: 7*24*60*60*1000 }
}));
app.use(express.static(path.join(__dirname, 'public')));

const otpStore = new Map();
const twilioConfigured = process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_PHONE_NUMBER;
async function sendOtp(phone, code) {
  if (twilioConfigured) {
    const twilio = require('twilio')(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
    await twilio.messages.create({ body: `Your messenger verification code: ${code}`, from: process.env.TWILIO_PHONE_NUMBER, to: phone });
  } else {
    console.log(`[DEV ONLY] OTP for ${phone}: ${code}`);
  }
}
function validPhone(p){ return typeof p === 'string' && /^\+[1-9]\d{7,14}$/.test(p); }
function requireAuth(req,res,next){ if(!req.session.userId) return res.status(401).json({error:'Please sign in'}); next(); }

app.post('/api/send-code', async (req,res)=>{
  const phone=(req.body.phone||'').trim();
  if(!validPhone(phone)) return res.status(400).json({error:'Enter phone in international format, e.g. +15551234567'});
  const code=String(crypto.randomInt(100000,1000000));
  otpStore.set(phone,{code,expires:Date.now()+5*60*1000,attempts:0});
  try { await sendOtp(phone,code); res.json({ok:true, message: twilioConfigured?'SMS sent':'Development code printed in server terminal'}); }
  catch(e){ console.error(e); res.status(500).json({error:'Could not send SMS. Check SMS settings.'}); }
});
app.post('/api/verify', (req,res)=>{
  const phone=(req.body.phone||'').trim(), code=(req.body.code||'').trim();
  const item=otpStore.get(phone);
  if(!item || Date.now()>item.expires || item.attempts>=5) return res.status(400).json({error:'Code expired. Request a new one.'});
  item.attempts++;
  if(item.code!==code) return res.status(400).json({error:'Incorrect code'});
  otpStore.delete(phone);
  let user=db.users.find(u=>u.phone===phone);
  if(!user){ user={id:crypto.randomUUID(),phone,joined:Date.now()}; db.users.push(user); save(); }
  req.session.userId=user.id;
  res.json({ok:true,user:{id:user.id,phone:user.phone}});
});
app.post('/api/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me', (req,res)=>{
  const user=db.users.find(u=>u.id===req.session.userId);
  res.json({user:user?{id:user.id,phone:user.phone}:null});
});
app.get('/api/users',requireAuth,(req,res)=>{
  res.json(db.users.filter(u=>u.id!==req.session.userId).map(u=>({id:u.id,phone:u.phone})));
});
app.get('/api/messages/:userId',requireAuth,(req,res)=>{
  const other=req.params.userId;
  const list=db.messages.filter(m=>(m.from===req.session.userId&&m.to===other)||(m.from===other&&m.to===req.session.userId));
  res.json(list);
});
app.post('/api/messages',requireAuth,(req,res)=>{
  const to=req.body.to, text=(req.body.text||'').trim();
  if(!db.users.some(u=>u.id===to)) return res.status(404).json({error:'User not found'});
  if(!text || text.length>2000) return res.status(400).json({error:'Message must be 1–2000 characters'});
  const msg={id:crypto.randomUUID(),from:req.session.userId,to,text,at:Date.now()};
  db.messages.push(msg); save(); res.json(msg);
});
app.listen(PORT,()=>console.log(`Messenger running: http://localhost:${PORT}`));
